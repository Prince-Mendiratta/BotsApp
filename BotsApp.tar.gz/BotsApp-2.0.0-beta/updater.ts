import gitPull from './core/gitpull';

(async () : Promise<void> => {
    await gitPull();
})();